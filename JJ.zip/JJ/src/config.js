// src/config.js

const motorcycles = [
  { name: 'Classic 350', img: 'https://www.royalenfield.com/content/dam/royal-enfield/motorcycles/new-classic-350/book-a-test-ride/book-a-test-ride-300x210.png' },
  { name: 'Guerrilla 450', img: 'https://www.royalenfield.com/content/dam/royal-enfield/motorcycles/guerrilla-450/guerrilla-450-300x210.jpg' },
  { name: 'Shotgun 650', img: 'https://www.royalenfield.com/content/dam/royal-enfield/shotgun-650/book-a-test-ride/book-a-test-ride-300x210.png' },
  { name: 'New Himalyan', img: 'https://www.royalenfield.com/content/dam/royal-enfield/motorcycles/himalayan/new-himalayan-300x210.jpg' },
  { name: 'Bullet 350', img: 'https://www.royalenfield.com/content/dam/royal-enfield/bullet/bullet-350-300x210.png' },
  { name: 'Super Meteor 650', img: 'https://www.royalenfield.com/content/dam/royal-enfield/super-meteor-650/motorcycles/forms/book-test-ride-300x210.png' },
  { name: 'Scram 411', img: 'https://www.royalenfield.com/content/dam/royal-enfield/india/motorcycles/book-a-test-ride/ga-book-test-ride/thumbnail/royal-enfield-scram-11-300x210.png' },
  { name: 'Hunter 350', img: 'https://www.royalenfield.com/content/dam/royal-enfield/hunter-350/book-test-ride.png' },
  { name: 'Meteor 350', img: 'https://www.royalenfield.com/content/dam/royal-enfield/motorcycles/meteor-350/thumbnail/meteor-300x210.png' },
  { name: 'Interceptor 650', img: 'https://www.royalenfield.com/content/dam/royal-enfield/india/motorcycles/interceptor/new/interceptor-book-a-test-ride-300x210.png' },
  { name: 'Continental GT', img: 'https://www.royalenfield.com/content/dam/royal-enfield/india/motorcycles/continental-gt/new/continental-gt-book-a-test-ride-300x210.png' },
];
  
  export default motorcycles;